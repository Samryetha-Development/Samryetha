# Lako UI 组件与视觉契约

## 引入与主题

```tsx
import { DataTable, useDataTable, LakoHorizontalTab, LakoDropdown,
  LakoPaginator, LakoAccountDropdown, LakoVerticalNavigator,
  LakoBreadcrumbNavigator, LakoRouterProvider, LakoDialog,
  LakoTimeDialog, LakoIcon } from '@lako/ui/components';
import '@lako/ui/ui.css';
```

组件外观、交互态和动画均包含在 `ui.css`，不是只导出无样式的行为。`playground/collections.css` 只负责展示页布局和业务单元格，不应该被业务项目引入。

主题通过 `--lako-ui-*` token 配置，也兼容现有 `--bg`、`--surface`、`--ink`、`--muted`、`--line`、`--accent`、`--accent-soft` 等应用 token。组件不会替应用切换主题。深色示例在 `playground/collections.css` 中显式设置应用 token；只设置 `data-theme` 而不提供深色颜色 token，不会自动创造完整主题。

键盘焦点、hover、禁用态和减少动态效果都是组件契约。`prefers-reduced-motion: reduce` 或根节点 `data-reduce-motion="true"` 会停用对应过渡。图片中的字号/尺寸需按 CSS 像素比较，不能把截图缩放后的像素当成 CSS 像素。

## 视觉与动画基准

以下是从 Nedmori 源码及浏览器 computed styles 对照提取的默认值；不是所有组件都统一变成同一套大小。

| 部位 | 默认几何 | 动效 / 交互 |
| --- | --- | --- |
| Paginator | 左右按钮 34×34px，SVG 18px，页码最小宽 42px | 按钮 hover/focus/disabled，边界禁止翻页 |
| DataTable | 表头 12px，单元格 14px、上下 padding 15px | 行 hover 背景 120ms；搜索/筛选/排序/翻页后内容淡入 180ms |
| 示例题名单元格 | 题名 16px/600，元信息 12px | 这些业务样式属于展示页，不固化进 Table 引擎 |
| 示例状态标记 | SVG 17px | 通过：绿色圈勾；尝试：黄色空心圈；未尝试：空白 |
| HorizontalTab | 标签 14px、计数徽章 20px 高 | 下划线 220ms；面板离场 95ms，进入时先置透明再淡入；连续选择以最后一次为准 |
| Dropdown | 触发器 40px，搜索输入 34px，选项最小高 34px | 面板淡入 110ms、位移 140ms；选项 hover 120ms |
| AccountDropdown | 菜单 220px、padding 5px；头像 32px；操作行 36px、图标 16px | 顶右原点，淡入/出 110ms、上移 4px/140ms；退出时保留 DOM 并设 inert |
| TimeDialog | 复用 Dialog；日期视图容器固定 280px，时/分输入 48px | 月份双页横移 375ms；层级切换采用 150ms 退场、150–500ms 入场；可被下一次交互打断 |

## DataTable：controller 与组合结构

`useDataTable` 返回原生 TanStack Table v8 instance。列直接使用 TanStack `ColumnDef<T>`，复杂情况直接访问该 instance，不再维护一套不兼容的列定义。

```tsx
const columns: ColumnDef<Problem>[] = [
  { id: 'status', header: '', enableSorting: false,
    cell: ({row}) => <ProblemStatus status={row.original.status}/> },
  { accessorKey: 'title', header: 'Problem',
    cell: ({row}) => <ProblemCell problem={row.original}/> },
  { accessorKey: 'difficulty', header: 'Difficulty' },
];
const table = useDataTable({
  data, columns, getRowId: row => row.id,
  pagination: {pageSize: 20},
  filtering: {global: true}, sorting: true, selection: true,
});
return <DataTable.Root table={table}>
  <DataTable.Toolbar>
    <DataTable.Search label="Search problems"/>
    <DataTable.Filter column="difficulty" options={options} searchable/>
    <DataTable.Pagination/>
  </DataTable.Toolbar>
  <DataTable.Grid ariaLabel="Problems" selection/>
</DataTable.Root>;
```

- `Root` 只传递 controller，不创建另一份状态。
- `Toolbar` 可自由排布，分页可以放顶部或底部。
- `Grid` 组合语义 table、Header 和 Body；需要自定义结构时使用 `LakoTable` + `DataTable.Header` + `DataTable.Body`。
- `Grid` 的 `empty`、`loading`、`selectAllLabel`、`selectRowLabel` 可控制空状态和可访问名称。
- Marks 是业务 Cell。库不知道“通过/尝试/未解决”，不按 ID、行号或随机数生成状态。
- 选择使用稳定 `getRowId`；全选只选当前页，切页保留已选 ID。应用负责在权限变化和数据删除后清理失效选择。
- Table 默认不启用拖拽；需要手动顺序时，通过可选 `rowReorder` 接入。排序数据和持久化仍由应用负责。

### 服务端模式

```tsx
const table = useDataTable({
  data: response.items, columns, getRowId: row => row.id,
  pagination: {mode:'manual', pageIndex: page.pageIndex,
    pageSize: page.pageSize, pageCount: response.pageCount, onChange:setPage},
  filtering: {mode:'manual', global:true, query,
    onQueryChange:setQuery, state:filters, onChange:setFilters},
  sorting: {mode:'manual', state:sorting, onChange:setSorting},
});
```

回调遵循 TanStack updater 语义，既可能接收值，也可能接收 `(previous) => next`。manual 模式不会对服务端返回的一页再次过滤、排序或分页；`pageCount` 必须由服务端显式提供，不能用当前页长度猜总数。搜索/筛选/排序交互会重置页码。请求取消、旧响应抑制、URL 同步、缓存更新属于应用数据层。

## HorizontalTab / View Change

```tsx
<LakoHorizontalTab ariaLabel="Collection view"
  items={[{id:'all',label:'All problems',count:20},{id:'saved',label:'Saved',count:0}]}
  value={view} onChange={setView} toolbar={<Search/>}>
  {committed => committed === 'all' ? <AllProblems/> : <SavedProblems/>}
</LakoHorizontalTab>
```

`value` 控制立即移动的选中项；`children` 接收动画提交后的视图，不要在 `children` 内改读外部 `value` 而绕过退出阶段。支持方向键、Home/End 和跳过禁用项。需要纯标签条而不切内容时直接使用 `LakoTabs`。Tab 不负责发请求或改 URL。

## Dropdown（searchable）

```tsx
<LakoDropdown ariaLabel="Time zone" items={zones} value={zone}
  getKey={z=>z.id} getLabel={z=>z.label} getSearchText={z=>z.label}
  onChange={setZone} useSearch searchPlaceholder="Search time zones…"/>
```

搜索栏和选项滚动层是两个独立层：`.lako-ui-dropdown-search-wrap` 位于滚动 listbox 外面；只有 `.lako-ui-dropdown-scroll` 滚动。这样选项无法穿到搜索栏的边距上。关闭后保留内容至 CSS 退出结束，下一次打开才重置搜索，避免退出时列表突然跳变。箭头键移动活动选项并滚入可见区域，Enter 选择、Escape 关闭并返回焦点。

## Paginator

`pageIndex` 从 0 开始，`pageCount` 是总页数。`onPageChange` 收到新 index。0 条数据时显示 `0 / 0` 且两边禁用；最后一页禁用下一页。通过 `formatPage`、`previousLabel`、`nextLabel`、`ariaLabel` 本地化。箭头是 SVG，不依赖字体里的 ‹/› 字形。

## AccountDropdown

传入 `name`、`avatar`、`profileHref`、`items`，每项可配置 `icon`、`href` 或 `onSelect`、`disabled`、`separatorBefore`。图标使用调用方提供的 ReactNode；示例显式提供设置/退出 SVG，不由库根据英文文案猜操作。

鼠标悬停触发器即展开，不移动键盘焦点；穿过按钮与菜单间的 8px 过渡区域仍保持展开。离开后延迟 180ms 关闭，移回取消计时。触屏不因 pointerenter 打开，使用点击切换；点击已悬停展开的触发器不会意外收起。键盘通过 Enter/Space 或 ArrowDown 进入第一项，ArrowUp 进入末项；菜单内方向键、Home/End 移动，Escape 关闭回触发器，Tab 正常离开。

关闭后保留 DOM 以完成 fade/位移动画，同时 `aria-hidden` + `inert` 阻止交互；不是立刻卸载。`onNavigate` 可接业务路由；修饰键点击保留浏览器默认行为。

## VerticalNavigator / BreadcrumbNavigator

```tsx
<LakoRouterProvider adapter={{subscribe:router.subscribe,
  getSnapshot:()=>router.location, getServerSnapshot:()=>initialLocation,
  getMatches:location=>router.matches(location), navigate:router.navigate}}>
  <LakoBreadcrumbNavigator/>
  <LakoVerticalNavigator title="Administration" items={navigation}/>
</LakoRouterProvider>
```

adapter 的 `getSnapshot()` 必须返回稳定 location 字符串。`getMatches` 返回 `{id,label,href}` 祖先链，动态名称由路由层提供。组件通过 `useSyncExternalStore` 订阅更新；不拼拆 pathname 猜面包屑。`back` 模式只显示真实父级，组织比赛的父级由应用路由声明。VerticalNavigator 按最长匹配 href 高亮，保持普通 anchor 行为。

## Dialog TextInput

```tsx
<LakoDialog type="TextInput" open={open} onOpenChange={setOpen}
  title="Join organization" inputLabel="Invitation code"
  placeholder="Enter invitation code" confirmLabel="Join"
  validate={code=>code.length<6?'Use at least six characters':undefined}
  onConfirm={async code=>{ await join(code); }}/>
```

空输入可由 `required` 控制。验证错误不关闭；`onConfirm` 返回/resolve false 不关闭；异常作为输入错误显示。异步中锁住确认和关闭，Enter 不在 IME composition 期间提交。`LakoTextInputDialog` 是同一实现的直接入口。

## TimeDialog

```tsx
<LakoTimeDialog open={open} onOpenChange={setOpen} title="End time"
  value={endAt} timeZone="Asia/Shanghai" locale="en"
  onConfirm={instant=>{
    if(Date.parse(instant)<=Date.parse(startAt)) {
      notify('End time must be after start time.'); return false;
    }
    setEndAt(instant);
  }}/>
```

- `value` / `onConfirm` 使用 ISO UTC 时间，不使用无时区字符串冒充实际时刻。
- 时区由调用方传入，同一表单的 start/end 共享同一个时区；库不读写 localStorage。
- 点年月标题进入月份，再点年份进入年份选择。日期方向键、今天、时分分段输入和减少动态效果均保留。
- DST 缺失时间禁止确认。重复时间优先保留已存在、且与输入吻合的 value，否则选较早实际时刻。
- `onConfirm` 可同步/异步返回 false，拒绝后弹窗保持打开且保留选择，应用自行呈现业务错误。抛出异常会显示对话框错误。
- locale 控制日期名称，`labels` 覆盖按钮、输入标签和错误消息；库不依赖 Nedmori 的 i18n。

## 本地预览与验证

`pnpm dev` 后打开 `/collections.html`。`pnpm typecheck`、`pnpm test`、`pnpm build:playground` 分别检查类型、交互/状态和可运行示例产物。自动化通过不等于所有动画逐帧、屏幕阅读器和触屏组合都已验证；验证边界记录在 `VALIDATION.md`。

### 显式批量选择模式

展示页默认隐藏选择列，点击 `Edit` 后在同一位置淡入操作栏。普通工具栏和选择栏互斥，隐藏侧使用 `inert` 与 `aria-hidden`；进入/退出后转移键盘焦点。分页始终留在表格上方，不随模式替换。

```tsx
<DataTable.Root table={table}>
  {selecting ? <DataTable.SelectionBar
    onExit={() => { setSelecting(false); table.resetRowSelection(true); }}
    formatCount={count => `已选 ${count} 项`}
    selectPageLabel="选择本页" clearLabel="清空选择" doneLabel="完成">
    <LakoButton disabled={!selectedCount} onClick={applyToSelected}>添加到题单</LakoButton>
  </DataTable.SelectionBar> : <BrowseToolbar/>}
  <DataTable.Grid selection={selecting}/>
</DataTable.Root>
```

`SelectionBar` 提供数量、选择本页、清空和退出回调；`children` 是业务操作插槽。计数包含跨页已选 ID，清空覆盖所有页面；退出是否清空由应用决定。删除、添加和确认 Dialog 不由组件猜测执行。`ariaLabel` 和各文案可本地化。

### 可选的自动选择组合

应用也可以按 `selectedCount > 0` 自动切换工具栏，并始终设置 `Grid selection` 保留选择列。当前 collections 预览采用下文的 Edit / Done 模式；自动选择仅是另一种组合方式，不是 controller 的强制行为。状态标记始终是独立的业务列。

`SelectionBar` 的 `onExit` 可省略，省略时不渲染 Done；`onClear` 在清空状态后通知应用，可用于把焦点送回搜索框。示例的 Add to collection 是页内演示，不写入业务服务。

### 整行点击与选择并存

```tsx
<DataTable.Grid selection
  rowClickMode={selectedCount > 0 ? 'select' : 'activate'}
  onRowActivate={id => navigate(`/problems/${id}`)}/>
```

`onRowActivate(id, event)` 由应用处理导航；`rowClickMode="select"` 时只切换可选行。行内链接、按钮、表单控件、label、可编辑区以及标记 `data-row-interactive` 的区域不会触发行操作。修饰键点击、已阻止的事件和拖动文字选择也不会触发行操作。标题应使用真实 `<a href>`，保留浏览器新标签页、右键菜单和键盘导航。组件不为 `<tr>` 伪造 button role 或额外 tab stop。

小样使用 hash 路由打开题目预览 Dialog，演示导航与选择独立，不替代应用题目详情页。

### 可选拖拽排序

```tsx
<DataTable.Grid selection rowReorder={{
  handleLabel: id => `调整 ${id} 的顺序`,
  onReorder: (sourceId, targetId, placement) => {
    // 在应用的有序数据中移除 sourceId，再插入 targetId 的 before / after 位置。
    // 根据稳定 ID 更新顺序；网络保存、冲突处理由应用负责。
  },
}}/>
```

启用后增加固定 36px 手柄列，手柄使用 Pointer Events，鼠标和触屏都从手柄发起拖动；5px 阈值避免误触。拖动时行跟随指针，相邻行实时让位。移出表格释放、pointercancel 或 Esc 取消。键盘：手柄按 Space/Enter 拿起，上下键调整目标，Space/Enter 确认，Esc 取消；离开手柄也取消未提交的键盘移动。放下后恢复手柄焦点，读屏通过 live region 播报状态。

拖拽只处理当前显示的行；应用按 ID 修改原始顺序，隐藏行不会被丢弃，跨页已选 ID 保留。启用列排序时暂时禁用拖拽，避免手动顺序被列排序覆盖。`disabled` 可以额外禁止排序。小样只在当前页面内调整顺序，刷新后恢复示例数据；未接业务存储。

### Edit / Done 交互小样

当前展示页改为显式编辑模式实验：默认浏览时收起选择框和手柄列（0px）；Edit 后展开为 44px/36px，整行点击变为选择，标题链接仍独立导航；Done 清空选择并返回浏览，保留已调整的顺序。展开时内容三列按 60:18:22 等比例收窄，列宽过渡 220ms；退出则回收空间。自动选择模式仍可按前述组合方式接入，不是 controller 的强制行为。

### 浏览排序与手动顺序

小样的难度列按 Beginner → Elementary → Intermediate → Advanced 排序，通过率按数值排序，缺失值放末尾。表头点击循环切换方向与无排序。进入 Edit 清除表头排序、展示手动顺序；编辑期间表头不提供自动排序按钮，避免列排序覆盖拖拽结果。Done 后仍展示当前手动顺序，可再次点击表头查看排序结果。

### 拖拽实时让位

拖拽开始时测量可见行的位置和高度。移动过程中按冻结的行中心计算预览顺序，相邻行用 transform 实时腾出空位，不按已移动的 DOM 反复命中，避免来回跳位。行高可不同，偏移按实际高度累计。放下时用 180ms 过渡吸附到空位，再通知应用更新顺序；取消则回到原位。减少动态效果时立即完成。原先仅显示插入线的提示已替换为行让位。

### VerticalNavigator 动效

选中背景和左侧短线使用同一个共享指示层，依据真实链接位置移动与缩放；切换 240ms（cubic-bezier(.22,.8,.24,1)），无匹配路由时 140ms 淡出。第一次测量直接定位，避免从左上角飞入；连续切换由当前过渡位置直接转向。ResizeObserver、窗口变化和字体就绪后重新测量，兼容展示页窄屏横排。hover 和键盘焦点独立于选中指示层。减少动态效果时直接定位。

### 页面滚动条占位

`ui.css` 在根元素使用 `scrollbar-gutter: stable`，长短内容切换及 Dialog 锁住 body 滚动时保持内容可用宽度。未支持该属性的浏览器回退到根元素 `overflow-y: scroll`；不再叠加手动 padding 补偿。浮动滚动条由浏览器按自身行为处理。

### AccountMenu 图标

账户入口和菜单统一使用 Lucide 线框图标：UserRound / Shield / SlidersHorizontal / LogOut。统一 24×24 viewBox、1.6 描边、无填充和圆角端点；显示尺寸均为 16px，沿用 currentColor，不用透明度补偿实心图标重量。仅静态导入所需图标。许可声明见 `docs/lucide-LICENSE.txt`。

### Dialog 退出内容保留

关闭时父级可以立即清空路由数据；Dialog 在退出阶段渲染最后一次已提交的打开状态，包括标题、说明、正文、操作区与样式。180ms 退出结束后清理引用，避免空标题、残缺说明或高度跳变。重新打开立即使用新内容，并取消旧的退出计时；减少动态效果时直接卸载。

焦点与滚动锁由整个呈现生命周期持有，直到退出完成才释放；忙碌状态或 `dismissible` 变化不会重新捕获焦点。多个弹窗同时存在时仅最上层处理 Escape / Tab，关闭子弹窗后父弹窗继续锁住滚动；底层弹窗提前卸载也不会解除上层的锁。确认回调和业务状态仍由调用方管理。

系统 `prefers-reduced-motion` 与根节点 `data-reduce-motion="true"` 采用同一个内部判断，供 Dialog、Tab、拖拽落位与日历切换使用。Dialog 退出中启用任一设置会立即完成退出，并清理定时器及监听器。这个内部实现不新增公开入口。
