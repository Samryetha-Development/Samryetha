# 验证记录

日期：2026-09-26。

## 已完成

- `@lako/ui` 和 `samryetha-ui-commons` 类型检查、ESM 与声明构建通过。
- 14 项 Node 测试通过：旧入口兼容、导出文件存在、SSR 字段标签与说明关联、加载按钮、复选框 mixed/ref/受控状态、列表和紧凑单选的标签选择与禁用行为、原生表单提交及重置、弹窗 Esc 关闭与焦点返回。
- 主论坛、Lako Web、Tasks 和 i18n 的类型检查与生产构建通过。
- 组件展示页生产构建通过；在内置浏览器检查了浅色渲染与窄视口，未发现横向溢出。
- 两套实际 tarball 在仓库以外的空项目安装成功，Node ESM/SSR 导入、TypeScript NodeNext 解析与 CSS 子路径解析通过。
- tarball 包含声明、JS、CSS、README 与 LICENSE，未包含环境文件或展示页构建产物。
- 选择控件重构：14px 透明轮廓、1px 边框、独立 SVG 勾/横线/圆点；紧凑单选改为文字与细下划线。没有新增颜色 token、阴影、渐变、填充胶囊或选择动画。
- 在 `/selection-preview.html` 实测浅色与深色渲染、hover 后背景仍透明、单选方向键切换和跳过禁用项、Space 切换半选复选框、1px 键盘焦点轮廓。主展示页未改布局；与改动前 CSS 对照，非选择控件规则保持一致。

## 尚未完成

- 早期主展示页的自动化点击未生效，搜索、页签键盘及完整浏览器流程仍未全部验证。此次独立选择控件预览中的点击和键盘已实测；这不代表其它控件的浏览器验证已完成。
- 尚未上传到组织仓库或发布到 registry；组织平台、最终 scope/name 与可见性待实际发布时确定。

## 已知构建提示

展示页 Vite 构建提示客户端 bundle 不保留 `use client`，该展示页本身不使用 RSC；库使用 tsc 输出，发布入口保留此指令，Lako Next 构建通过。主论坛还有既有 Vite `__dirname` 配置提示。


## 2026-10-18：Collection、导航及输入弹窗

- 新增 DataTable/TanStack v8 controller、独立 Paginator、HorizontalTab/View Change、AccountDropdown、路由适配器及 Vertical/Breadcrumb 导航、Dialog TextInput 类型、独立 TimeDialog。已有 searchable Dropdown 保留并补齐搜索栏底色。
- 库与 playground 类型检查、声明/ESM 构建、20 项测试通过。新增覆盖客户端过滤/排序/分页、稳定 ID 选择、manual 服务端模式、分页边界、真实路由 matches、输入弹窗异步拒绝、TimeDialog 拒绝关闭及 DST 跳时。
- 内置浏览器检查 `/collections.html`：搜索、带搜索的筛选、分页、选择、Tab View Change、账户菜单、TimeDialog 月份/年份层级、TextInput 错误显示；已检查深色桌面效果。此记录不宣称动画逐帧或所有窄屏/读屏器组合均已验证。
- 打包到 `.artifacts/collections-20261018/lako-ui-0.1.0.tgz`；检查 tar 内全部 exports 和相对导入完整，在 `.artifacts/collections-smoke` 隔离安装后验证根入口、components 入口及服务端渲染。
- 组件源码与文档已更新，尚未发布到 registry；Nedmori 当前的 vendor 包和业务页面尚未迁移到这份新包。应用自行提供路由适配器、请求取消、URL 状态、业务 Marks 与确认规则。


### 2026-10-18：视觉提取修正

- 按 Nedmori computed styles 核对默认几何：分页按钮 34px、状态 SVG 17px、账户菜单 220px；示例题库改用公开题库元信息快照，状态按数据绘制，不使用字符或按行号猜状态。
- AccountDropdown 保留关闭期间 DOM，恢复顶右原点 4px 位移/110–140ms fade 与 hover/focus；DataTable 的选择使用现有 LakoCheckbox，恢复行 hover/内容淡入；Tab 增加 count 徽章并纠正 entering 阶段 transition。
- searchable Dropdown 将搜索栏与选项滚动层分离，避免顶部穿透；关闭时保持搜索内容以完成退出，重新打开再清空。
- 23 项测试通过（新增 SVG 分页箭头、搜索栏不在滚动 listbox 内、账户菜单退出期间 inert）。完整视觉/API 文档新增 `docs/components.md`，随包分发。

### 批量选择布局修正

- 新增可组合的 `DataTable.SelectionBar`；计数、选本页、跨页清空和业务操作插槽。
- 展示页默认浏览模式；显式进入批量模式，工具栏淡入切换，隐藏侧 inert，进出转移焦点。
- 24 项测试通过；类型检查与 playground 构建通过。浏览器验证跨页保留、退出清空、焦点返回及选择样式。

### 自动选择与行导航小样

- 自动选择栏不需要 Manage/Done；表头选择框在已有选择时出现。
- 普通行点击激活，选择模式点击行切换选择；真实标题链接始终独立导航。
- 浏览器验证普通行导航、复选框不导航、选择模式连续点行、标题打开后保留选择。
- 类型检查、playground 构建通过；26 项组件测试通过，含交互控件与修饰键不触发行操作。

### 可组合拖拽排序

- DataTable 的可选 `rowReorder` 增加独立手柄，Pointer Events 拖动、阈值、插入提示、放下/取消与键盘排序。
- 应用通过 source/target ID 和 before/after 更新有序数据，库不发送请求；列排序时禁用手动拖动。
- 浏览器实际拖动 P1001 到 P1003 后，顺序变为 P1002/P1003/P1001；键盘继续调整，已选 P1001 状态保留。
- 类型检查、playground 构建通过；28 项测试通过，包括键盘放下/取消、指针阈值与表外释放取消。真实触屏尚未验收。

### 修正拖拽只有插入线、不会让位

- 相邻行实时预览位移；冻结原始几何以避免命中已变换元素引起抖动。
- 放下先落位再提交顺序，取消还原；键盘同样预览让位。
- 浏览器测量 P1001 移到第三位时 P1002/P1003 各上移约 80.25px，鼠标拖放后顺序为 P1002/P1003/P1001，transform 清理。
- 28 项测试通过；指针测试验证放下前已让位、未调用排序回调，反复移动到同一位置不抖动。

### VerticalNavigator 共享高亮动效

- 背景和短线作为同一个指示层，240ms 位移/尺寸过渡，连续导航从当前过渡位置重定向。
- 首次直接测量定位；路由不匹配时淡出；窗口/元素尺寸和字体变化时重测；减少动态效果时不做过渡。
- 浏览器采样反向切换时目标 Y=53.69px、当前 Y=55.97px，确认切换过程中存在插值而非跳变。
- 29 项测试、类型检查与 playground 构建通过，覆盖路由变更、重测和无匹配隐藏。

### 防止页面滚动条造成横向位移

- 根元素 scrollbar-gutter: stable，不支持时回退 overflow-y: scroll。
- 浏览器实测长表格、短 Dialogs 内容、打开 TimeDialog、长页打开题目 Dialog：main.left 均为约 222.59px、width 约 1199.99px。
- 旧浏览器 fallback 未实机验收。

### AccountDropdown 悬停展开

- mouse pointerenter 展开且不抢焦点；8px 间隔桥接，移出后 180ms 延迟关闭、移回取消。
- 触屏保留点击切换；键盘 Enter/Space 与上下箭头进入菜单，Escape 返回触发器。
- 浏览器验证未点击触发器的指针移入展开、进入菜单保持、移出关闭。
- 31 项测试通过，覆盖 hover 不抢焦点、重入取消关闭、touch pointerenter 不触发、键盘与点击退化。

### AccountMenu 图标替换

- 使用官方 Font Awesome Free 6.7.2 的 circle-user、shield-halved、sliders、arrow-right-from-bracket；未使用第三方 Pro 镜像内容。
- 逐图标子路径导入，保留原 SVG 尺寸和 currentColor；保留 Font Awesome 完整许可证。
- 浏览器检查入口 18px、菜单 16px；31 项测试、类型检查通过。

### AccountMenu 统一线框重量

- 移除 Font Awesome Free 依赖与当前版本的对应声明，替换为 Lucide UserRound / Shield / SlidersHorizontal / LogOut。
- 统一 16px、24×24 viewBox、1.6 strokeWidth、fill=none，恢复不透明 currentColor。
- 浏览器逐个验证 fill/描边/实际尺寸；31 项测试、类型检查、playground 构建通过。

### 修复题目预览退出时清空内容

- LakoDialogBase 缓存最后一次已提交的打开状态呈现，退出动画期间保留，退出完成后清理。
- 浏览器采样 closing=true 时标题仍为 A + B Problem、说明仍为 P1001 · Problem preview。
- 32 项测试通过，新增同时关闭/清空数据、退出后卸载、重新打开新题目及快速关闭重开回归。

## 2026-10-18：样式维护清理

- 按组件合并重复规则与等价的 reduced-motion media query，保留最终级联值；移除无 DOM 的日期触发器、时区地图、重复根作用域选择器及已被实时让位覆盖的插入线。
- 保留公开 exports、Props、兼容参数和认证能力；仅移除 HorizontalTab 的宿主 `list-feed` 类名与 Playground 的未用 import。
- 浏览器保存整理前后桌面/390px 窄屏、明暗主题、编辑态、账户菜单与 TimeDialog 的截图及关键 computed styles，位于本地 `.artifacts/cleanup-20261018/`。完整桌面 DOM 对照未发现布局变化；焦点/hover 状态以及采样时尚未完成的过渡不作为静态样式差异。
- 此检查不宣称所有动画逐帧一致，未扩展到真实触屏或屏幕阅读器验收。

## 2026-10-18：指针与弹窗生命周期回归

- AccountDropdown 仅从 Pointer Events 接收悬停，删除重复 mouse fallback；保留触屏点击、重入取消延迟关闭、键盘与原生修饰键链接行为。
- Dialog 的呈现、焦点与滚动锁保持到退出结束；嵌套弹窗共享锁，只有顶层处理键盘；忙碌状态变化不重新 autofocus，快速重开取消旧退出任务。
- Dialog、Tab、日历与拖拽落位共享内部 reduced-motion 判断。系统与宿主开关均可跳过 Dialog 退出等待，退出中启用也立即清理；补齐 CSS 的 open / closing / animate 状态优先级。
- 44 项测试通过，含新增的忙碌状态焦点保持、嵌套及底层提前卸载、快速重开、两种 reduced-motion 来源和运行中变更、触屏兼容 mouse 事件、键盘退出与修饰键链接回归。
- 浏览器通过真实 CDP 鼠标事件验证 hover 不抢搜索焦点、移入菜单保持、移出关闭；验证键盘进入/退出、两种 reduced-motion 设置及 TimeDialog 滚动锁。拖动 P1001 到 P1003 后，相邻行先上移约 80.66px，落位后顺序为 P1002/P1003/P1001，选择保留且 transform 清理。控制台无 error。
- 发布验证使用排除既有认证修改的干净暂存快照：frozen-lockfile 安装、类型检查、44 项测试、Playground 构建、实际 tarball 与仓库外消费项目的 ESM / 类型 / SSR 及包内容完整性检查。保留既有的 Vite `use client` 展示页构建提示；不宣称真实触屏、读屏器或所有动画逐帧已验证。
- 未修改或提交既有 `src/login.tsx` / `src/auth.css` diff，未删除 `requestEmailCode`；未迁移 Nedmori、推送或发布。
